# Node.js To Do List

To test the application, access http://localhost:30080/todo from your developer workstation (the box host, NOT the workstation VM)

